import './App.css';
import Modal from './components/Model';

function App() {
  return (
    <>
      <Modal />
    </>
  );
}

export default App;
